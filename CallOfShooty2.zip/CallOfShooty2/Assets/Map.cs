﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour { //TODO: Bind the canvas to physical space, so the camera can later be controlled freely // Only not static, because monobehavior does weird stuff
	public GameObject exampleTile; // Temporary seed tile to copy the others from (Shortcut to get the correct dimensions and components)

	private static float globalMinX = -25; // local coordinates on the canvas // TODO: calculate -after- the tile dimensions are known
	//float globalMaxX = 25;
	private static float globalMinY = -15;
	//float globalMaxY = 15;
	private static float globalInc = 1; // unit of space between tile centers on the canvas

	public static Tile[,] currentMap = new Tile[50,30]; // TODO: Set size intelligently

	void Start () {
		for (int x = 0; x < currentMap.GetLength(0); x++) {
			for (int y = 0; y < currentMap.GetLength(1); y++) {
				GameObject newTile = Instantiate (exampleTile.gameObject); // Make the new gameobject
				newTile.name = "Tile (" + x + ", " + y + ")"; // Name it appropriately for debugging
				newTile.transform.parent = exampleTile.transform.parent; // Set its parent so local coordinates are consistent
				newTile.transform.localPosition = new Vector3 (globalMinX + globalInc/2 + x*globalInc, globalMinY + globalInc/2 + y*globalInc, 0); // Move the tile to the correct grid location
				newTile.transform.localScale = new Vector3 (4, 4, 1); // Just in case, scale it appropriately
				currentMap[x,y] = newTile.GetComponent<Tile>(); // Add the Tile to the array that tracks them
				currentMap[x,y].Set(0); // Set the tile to empty space //TODO: Load map from external file
			}
		}
		Object.Destroy(exampleTile); // It did its job with dignity. Farewell, valiant placeholder

		for (int x = 0; x < 50; x++) { // Throwing some walls up. Obsolete once maps are loaded from a file
			currentMap[x,0].Set(1);
			currentMap[x,29].Set(1);
		}
		for (int y = 0; y < 30; y++) {
			currentMap[0,y].Set(1);
			currentMap[49,y].Set(1);
		}

		for (int x = 0; x < currentMap.GetLength(0); x++) {
			for (int y = 0; y < currentMap.GetLength(1); y++) {
				SetHitboxes(x, y);
			}
		}
	}
	
	void Update () {
		if (Input.GetMouseButtonDown(0)) { // Temporary, for testing purposes
			int x = Mathf.FloorToInt((float) Input.mousePosition.x/16); // Figure out what tile is under the mouse
			int y = Mathf.FloorToInt((float) Input.mousePosition.y/16);
			if (x >= 0 && x < 50 && y >= 0 && y < 30) { // If it's not out-of-bounds
				currentMap[x,y].Set(1); // Set that tile to solid
				SetHitboxes(x,y);
				SetHitboxes(x+1,y);
				SetHitboxes(x-1,y);
				SetHitboxes(x,y+1);
				SetHitboxes(x,y-1);
			}
		}
	}

	public static void SetHitboxes(int x, int y) { // Sets up hitboxes pushing away from the tile, on all open sides (Not occupied by another tile. This avoids some really annoying issues, and is more efficient anyways)
		if (x < 0 || y < 0 || x > Map.currentMap.GetLength(0) || y > Map.currentMap.GetLength(1)) {
			return;
		}
		Map.currentMap[x,y].hitboxes = new List<CollisionBox>(); // Declared here rather than on the tile, because the tile may not have run Start() yet
		if (Map.currentMap[x,y].data == 1) { // TODO: Change to switch/case for all relevent tile collision types
			if (x + 1 < currentMap.GetLength(0) && currentMap[x+1,y].data == 0) {
				Map.currentMap[x,y].MakeHitbox(Vector2.right);
			}
			if (x > 0 && currentMap[x-1,y].data == 0) {
				Map.currentMap[x,y].MakeHitbox(Vector2.left);
			}
			if (y + 1 < currentMap.GetLength(1) && currentMap[x,y+1].data == 0) {
				Map.currentMap[x,y].MakeHitbox(Vector2.up);
			}
			if (y > 0 && currentMap[x,y-1].data == 0) {
				Map.currentMap[x,y].MakeHitbox(Vector2.down);
			}
		}
	}

	public static Vector2 CheckCollisions(Vector2 current, Vector2 intended, float radius) { // Checks for overlaps, displacing the resulting coordinate as little as possible to return a valid destination
		int minX = Mathf.FloorToInt(Mathf.Min(current.x, intended.x) - Player.radius) + 25; // Full set of tiles to check collisions with (Saves a lot of cpu cycles). Still useful even with non-square collisions
		int maxX = Mathf.CeilToInt(Mathf.Max(current.x, intended.x) + Player.radius) + 25;
		int minY = Mathf.FloorToInt(Mathf.Min(current.y, intended.y) - Player.radius) + 15;
		int maxY = Mathf.CeilToInt(Mathf.Max(current.y, intended.y) + Player.radius) + 15;

		List<Vector2> suggestions = new List<Vector2>(); // Keeps a list of all collisions found, but only resolves the nearest one (Avoids most cases of corner or velocity clipping)
		for (int x = Mathf.Max(0, minX); x < Mathf.Min(50, maxX); x++) { // Won't check out-of-bounds (nonexistent) tiles
			for (int y = Mathf.Max(0, minY); y < Mathf.Min(30, maxY); y++) { // Won't check out-of-bounds (nonexistent) tiles
				foreach (CollisionBox hitbox in Map.currentMap[x,y].hitboxes) {
					Vector2 suggestion = hitbox.Check(current, intended) - intended;
					if (suggestion.magnitude != 0) {
						suggestions.Add(suggestion);
					}
				}
				if (suggestions.Count > 0) { // Resolves corner cases with a somewhat dumb assumption
					suggestions.Sort((a, b) => a.magnitude.CompareTo(b.magnitude));
					intended += suggestions[0];
					if (suggestions[0].x > 0) { // Momentum resets //TODO: Tie into event system to handle stuff like wall-sliding and such
						Player.velocity.x = Mathf.Max(0, Player.velocity.x);
					}
					if (suggestions[0].x < 0) {
						Player.velocity.x = Mathf.Min(0, Player.velocity.x);
					}
					if (suggestions[0].y > 0) {
						Player.grounded = true;
						Player.velocity.y = Mathf.Max(0, Player.velocity.y);
					}
					if (suggestions[0].y < 0) {
						Player.velocity.y = Mathf.Min(0, Player.velocity.y);
					}
				}
				suggestions.Clear(); // Overlapping hitboxes are only culled if they are from the same source tile (corner cases)
			}
		}
		return intended;
	}
}
