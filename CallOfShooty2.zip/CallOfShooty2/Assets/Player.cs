﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Player : MonoBehaviour {
	public Transform trans;
	public static Vector2 position, velocity;
	public static float radius = 1f;

	public static float gravity = 0.09f; // Downward impulse per frame
	public static float friction = 0.95f; // Portion of momentum kept per frame //TODO: Break into individual vectors, and into air/ground friction
	public static float friction2 = 0.02f; // Reduce by this, to a minimum of 0
	public static float impulse = 0.06f; // Velocity added per frame, if given directional input
	public static float jump = 1.2f;
	public static float diagonal = Mathf.Sqrt(Mathf.Pow(impulse, 2) / 2f); // Impulse on each axis, to maintain consistent overall acceleration

	public static bool grounded = false; // Could use an int instead for a jump grace period
	public static int jumpCooldown = 0; // Only cools down while grounded

	void Start () {
		position = trans.localPosition;
	}
	
	void Update () {
		velocity.y -= gravity;
		velocity.x *= friction; // TODO: calculate friction differently
		velocity.y *= friction;

		if (velocity.x > 0) {
			velocity.x = Mathf.Max(0, velocity.x - friction2);
		} else {
			velocity.x = Mathf.Min(0, velocity.x + friction2);
		}
		if (velocity.y > 0) {
			velocity.y = Mathf.Max(0, velocity.y - friction2);
		} else {
			velocity.y = Mathf.Min(0, velocity.y + friction2);
		}

		UseInputs();

		if (grounded) {
			jumpCooldown = Mathf.Max(0, jumpCooldown - 1);
		} else {
			//Input buffering goes here?
		}
		grounded = false;

		UpdatePosition();
	}

	private void UseInputs() { // Temporary
		bool up = false;
		bool down = false;
		bool left = false;
		bool right = false;
		if (Input.GetKey("w")) {
			up = true;
		}
		if (Input.GetKey("a")) {
			left = true;
		}
		if (Input.GetKey("s")) {
			down = true;
		}
		if (Input.GetKey("d")) {
			right = true;
		}

		float useThis = impulse;
		if ((new []{up, down, left, right}).Count(n=>n) == 2) { // Either diagonal, or an opposite pair that cancels out anyways (Thus safe to assume diagonal)
			useThis = diagonal; // Slower impulse speed if also attempting to go up or down //TODO: Remove this?
		}
		if (up) {
			if (jumpCooldown == 0 && grounded) {
				velocity.y = jump;
				jumpCooldown = 10;
			}
		}
		if (down) {
			velocity.y -= useThis;
		}
		if (left) {
			velocity.x -= useThis;
		}
		if (right) {
			velocity.x += useThis;
		}
	}

	private void UpdatePosition () {
		int steps = 16; // Number of smaller segments the intended movement is broken into. More = smoother/safer, but more cpu expensive
		Vector2 step = velocity/steps;

		for (int n = 0; n < steps; n++) {
			position = Map.CheckCollisions(position, position + step, Player.radius);
		}

		trans.localPosition = new Vector3(position.x, position.y, 0); // Update the actual position of the gameobject/sprite
	}
}