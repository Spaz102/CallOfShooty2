﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour {
	public SpriteRenderer display;
	public Transform trans;
	public int data; // TODO: Split into multiple read-only flags
	public List<CollisionBox> hitboxes;

	void Start () {
		//this.hitboxes = new List<CollisionBox>(); // List is used in Map.Start() before it is declared here
	}
	
	void Update () { // Animate sprites?
		
	}

	public void SetColor(float n) { // Temporary
		display.color = RandomColor(n);
	}

	public void Set(int data) { //TODO: Tie into tilemap system
		this.data = data;
		if (this.data == 1) { // TODO: Set/recolour/rescale(!) sprites here
			this.SetColor(0.7f);
		} else {
			this.SetColor(0.3f);
		}
	}

	public static Color RandomColor(float n) {
		return Random.ColorHSV(n - 0.05f, n + 0.05f, 0.5f, 0.6f, 1f, 1f); // Useless magic; good for debugging
	}

	public void MakeHitbox(Vector2 direction) {
		if (hitboxes == null) { // Debugging tool. Shouldn't come up anymore
			Debug.Log("Oops!");
			return;
		}
		if (direction.x != 0) { // This is a horizontal hitbox. Could all be simplified using trig
			Vector2 top = this.trans.localPosition + new Vector3(0, 0.5f, 0); // Currently the top center
			top += direction*0.5f; // Top left or right depending on direction
			Vector2 bottom = this.trans.localPosition + new Vector3(0, -0.5f, 0); // Currently the bottom center
			bottom += direction*0.5f; // Bottom left or right depending on direction
			hitboxes.Add(new CollisionBox(top, bottom, direction, Player.radius));
		} else { // This is a vertical hitbox
			Vector2 left = this.trans.localPosition + new Vector3(-0.5f, 0, 0); // Currently the left center
			left += direction*0.5f; // Top or bottom left depending on direction
			Vector2 right = this.trans.localPosition + new Vector3(0.5f, 0, 0); // Currently the right center
			right += direction*0.5f; // Top or bottom right depending on direction
			hitboxes.Add(new CollisionBox(left, right, direction, Player.radius));
		}
	}
}

public class CollisionBox {
	public Vector2 lefty, righty; // Two points that, along with the direction and given distance, form the rectangular hitbox (Useful later if implementing slopes)
	public Vector2 direction; // Normalized (magnitude = 1) //TODO use trig to obsolete this

	private Tile parent; // Needed to distinguish solid or one-way surfaces
	private float minX, minY, maxX, maxY; // Precalculated. Obsolete if player's hitbox changes

	public CollisionBox(Vector2 first, Vector2 second, Vector2 test, float distance) {
		this.lefty = new Vector2(first.x, first.y);
		this.righty = new Vector2(second.x, second.y);
		this.direction = new Vector2(test.x, test.y);
		SetDistance(distance);
	}

	public void SetDistance(float distance) { // Generally called once, but separated in case the player is resized during runtime
		this.minX = Mathf.Min(lefty.x, righty.x) - distance + Mathf.Max(direction.x*distance, 0);
		this.maxX = Mathf.Max(lefty.x, righty.x) + distance + Mathf.Min(direction.x*distance, 0);
		this.minY = Mathf.Min(lefty.y, righty.y) - distance + Mathf.Max(direction.y*distance, 0);
		this.maxY = Mathf.Max(lefty.y, righty.y) + distance + Mathf.Min(direction.y*distance, 0);
	}

	public Vector2 Check(Vector2 current, Vector2 intended) { // Returns the nearest valid destination coordinate
		if (intended.x > minX && intended.x < maxX && intended.y > minY && intended.y < maxY) { // Collision detected
			//TODO: Special check for one-way platforms (if parent != solid, only displace TOWARDS current to avoid unnecessary displacement)
			Vector2 output = intended;
			if (direction.x > 0) { // TODO: Find a cleaner way; ideally that also enables slopes robustly
				output.x = maxX;
			} else if (direction.x < 0) {
				output.x = minX;
			} else if (direction.y > 0) {
				output.y = maxY;
			} else if (direction.y < 0) {
				output.y = minY;
			}
			return output;
		}
		return intended;
	}
}